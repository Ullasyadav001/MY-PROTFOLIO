# Ullas Yadav L — Portfolio Website

A personal portfolio built from scratch with **HTML, CSS, and vanilla JavaScript** — no frameworks, no templates. Single fast-loading page, fully responsive, with dark/light themes.

## Features

- Responsive layout (phone → desktop)
- Dark & light themes: follows the system setting, with a manual toggle remembered per browser
- Terminal-style hero card and animated cursor
- Copy-to-clipboard contact details
- Accessible: semantic HTML, keyboard-visible focus states, `prefers-reduced-motion` respected

## Run locally

Just open `index.html` in a browser. No build step, no dependencies.

## Deploy free on GitHub Pages

1. Create a new repository on GitHub named exactly: `ullasyadav001.github.io`
2. In this folder, run:
   ```bash
   git init
   git add .
   git commit -m "Portfolio website"
   git branch -M main
   git remote add origin https://github.com/ullasyadav001/ullasyadav001.github.io.git
   git push -u origin main
   ```
3. Wait a minute or two, then open **https://ullasyadav001.github.io** — your portfolio is live.

Any time you edit the site, commit and push again to update it.

## Tech

| Layer | Choice |
|---|---|
| Markup | HTML5 (semantic) |
| Styling | Hand-written CSS (custom properties, grid/flex) |
| Behavior | Vanilla JavaScript (theme toggle, clipboard) |
| Fonts | Bricolage Grotesque · Public Sans · JetBrains Mono (Google Fonts) |
| Hosting | GitHub Pages |
